/* Mudar a figura (redes sociais) */

/* 1 - criar os objetos para os elementos que serão manipulados */

const obj_sel_rede_social = document.querySelector('#sel_rede_social')
const obj_img_rede_social = document.querySelector('#img_rede_social')
const obj_p_rede_social = document.querySelector('#p_rede_social')

/* 2 - adicionar um evento para chamar a função */

obj_sel_rede_social.addEventListener('change', FunMudaFigura)

/* 3 - Declarar as funções */

function FunMudaFigura() {
    obj_img_rede_social.setAttribute('src', 'Imagens/' + obj_sel_rede_social.value + '.png')
    obj_img_rede_social.setAttribute('alt', 'Logo ' + obj_sel_rede_social.value)
    obj_img_rede_social.setAttribute('title', 'Logo ' + obj_sel_rede_social.value)
    obj_p_rede_social.innerHTML = 'Logo ' + obj_sel_rede_social.value
}

